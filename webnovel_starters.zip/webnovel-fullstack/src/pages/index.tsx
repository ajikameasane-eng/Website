import React from 'react';

export default function Home() {
  return (
    <main style={{padding: 24}}>
      <h1>WebNovel — Fullstack Starter</h1>
      <p>This is a starter Next.js project. See README for instructions to run locally.</p>
    </main>
  );
}
