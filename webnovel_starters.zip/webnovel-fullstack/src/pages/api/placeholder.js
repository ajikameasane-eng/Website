export default function handler(req, res) {
  res.status(200).json({ ok: true, msg: 'Placeholder API. Implement auth and stories endpoints.' });
}
