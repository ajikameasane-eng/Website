import React from 'react';
export default function Header(){ return <header style={{padding:16}}><h2>WebNovel</h2></header>; }